# Textures Directory

Store texture files (PNG, JPG, HDR, etc.) here. This directory is reserved for assets used by RayEngine.
