# Models Directory

Store 3D models (OBJ, GLTF, FBX, etc.) here. This directory is reserved for assets used by RayEngine.
