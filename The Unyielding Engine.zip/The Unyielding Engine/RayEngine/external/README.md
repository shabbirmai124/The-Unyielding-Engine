# External Dependencies

This directory contains external libraries used by RayEngine. They are automatically fetched by CMake if missing.

- glad
- glfw
- glm
- imgui
