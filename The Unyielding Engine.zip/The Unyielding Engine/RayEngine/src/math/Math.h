#pragma once

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

namespace ray {
namespace math {

// Utility math functions can go here

} // namespace math
} // namespace ray
