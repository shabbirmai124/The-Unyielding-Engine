#pragma once

#include <vector>
#include <glm/glm.hpp>

namespace ray {

struct Vertex {
    glm::vec3 Position;
    glm::vec3 Normal;
    glm::vec2 TexCoords;
};

class Mesh {
public:
    Mesh(const std::vector<Vertex>& vertices, const std::vector<uint32_t>& indices);
    ~Mesh();

    void Draw() const;

private:
    void SetupMesh();

private:
    std::vector<Vertex> m_Vertices;
    std::vector<uint32_t> m_Indices;

    uint32_t m_VAO, m_VBO, m_EBO;
};

} // namespace ray
