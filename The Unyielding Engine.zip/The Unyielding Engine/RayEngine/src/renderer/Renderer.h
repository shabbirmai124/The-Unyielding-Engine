#pragma once

namespace ray {

class Renderer {
public:
    static void Init();
    static void Shutdown();
    static void Clear();
};

} // namespace ray
