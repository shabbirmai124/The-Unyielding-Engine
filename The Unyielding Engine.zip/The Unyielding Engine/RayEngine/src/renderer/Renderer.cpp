#include "Renderer.h"
#include <glad/glad.h>
#include <iostream>

namespace ray {

void Renderer::Init() {
    std::cout << "Renderer Initialized" << std::endl;
    glEnable(GL_DEPTH_TEST);
}

void Renderer::Shutdown() {
    std::cout << "Renderer Shutdown" << std::endl;
}

void Renderer::Clear() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

} // namespace ray
