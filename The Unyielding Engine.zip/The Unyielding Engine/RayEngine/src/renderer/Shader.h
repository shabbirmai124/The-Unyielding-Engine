#pragma once

#include <string>

namespace ray {

class Shader {
public:
    // Takes file paths to the shaders, not the source code strings
    Shader(const std::string& vertexPath, const std::string& fragmentPath);
    ~Shader();

    void Bind() const;
    void Unbind() const;

private:
    uint32_t m_RendererID;
    
    uint32_t CompileShader(uint32_t type, const std::string& source);
};

} // namespace ray
