#pragma once

#include <string>
#include <memory>
#include "Window.h"
#include "../renderer/Shader.h"
#include "../geometry/Mesh.h"
#include "../physics/PhysicsWorld.h"

namespace ray {

class Application {
public:
    Application(const std::string& name, uint32_t width, uint32_t height);
    virtual ~Application();

    Application(const Application&) = delete;
    Application& operator=(const Application&) = delete;

    void Run();

    Window& GetWindow() { return *m_Window; }

private:
    std::unique_ptr<Window> m_Window;
    std::unique_ptr<Shader> m_Shader;
    std::unique_ptr<Mesh> m_Mesh;
    std::unique_ptr<PhysicsWorld> m_PhysicsWorld;
    bool m_Running = true;
};

// To be defined in CLIENT
Application* CreateApplication();

} // namespace ray
