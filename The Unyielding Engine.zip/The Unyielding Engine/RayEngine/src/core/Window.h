#pragma once

#include <string>

struct GLFWwindow;

namespace ray {

class Window {
public:
    Window(const std::string& title, uint32_t width, uint32_t height);
    ~Window();

    Window(const Window&) = delete;
    Window& operator=(const Window&) = delete;

    void PollEvents();
    void SwapBuffers();
    bool ShouldClose() const;

    uint32_t GetWidth() const { return m_Width; }
    uint32_t GetHeight() const { return m_Height; }
    GLFWwindow* GetNativeWindow() const { return m_Window; }

private:
    void Init(const std::string& title, uint32_t width, uint32_t height);
    void Shutdown();

private:
    GLFWwindow* m_Window = nullptr;
    uint32_t m_Width = 0;
    uint32_t m_Height = 0;
    std::string m_Title;
};

} // namespace ray
