#include "Window.h"

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>

namespace ray {

static bool s_GLFWInitialized = false;

Window::Window(const std::string& title, uint32_t width, uint32_t height) {
    Init(title, width, height);
}

Window::~Window() {
    Shutdown();
}

void Window::Init(const std::string& title, uint32_t width, uint32_t height) {
    m_Title = title;
    m_Width = width;
    m_Height = height;

    if (!s_GLFWInitialized) {
        int success = glfwInit();
        if (!success) {
            std::cerr << "Could not initialize GLFW!" << std::endl;
            return;
        }
        s_GLFWInitialized = true;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    m_Window = glfwCreateWindow((int)m_Width, (int)m_Height, m_Title.c_str(), nullptr, nullptr);
    if (!m_Window) {
        std::cerr << "Could not create GLFW window!" << std::endl;
        glfwTerminate();
        return;
    }

    glfwMakeContextCurrent(m_Window);

    int status = gladLoadGLLoader((GLADloadproc)glfwGetProcAddress);
    if (!status) {
        std::cerr << "Failed to initialize Glad!" << std::endl;
        return;
    }

    glViewport(0, 0, m_Width, m_Height);

    glfwSetWindowUserPointer(m_Window, this);
    glfwSetFramebufferSizeCallback(m_Window, [](GLFWwindow* window, int width, int height) {
        Window* data = (Window*)glfwGetWindowUserPointer(window);
        data->m_Width = width;
        data->m_Height = height;
        glViewport(0, 0, width, height);
    });
}

void Window::Shutdown() {
    glfwDestroyWindow(m_Window);
}

void Window::PollEvents() {
    glfwPollEvents();
}

void Window::SwapBuffers() {
    glfwSwapBuffers(m_Window);
}

bool Window::ShouldClose() const {
    return glfwWindowShouldClose(m_Window);
}

} // namespace ray
