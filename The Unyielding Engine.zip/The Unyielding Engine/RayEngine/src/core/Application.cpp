#include "Application.h"
#include "../renderer/Renderer.h"
#include <iostream>
#include <vector>

namespace ray {

Application::Application(const std::string& name, uint32_t width, uint32_t height) {
    m_Window = std::make_unique<Window>(name, width, height);

    Renderer::Init();

    // Setup Shader
    m_Shader = std::make_unique<Shader>("assets/shaders/basic.vert", "assets/shaders/basic.frag");

    // Setup a basic Triangle
    std::vector<Vertex> vertices = {
        { { -0.5f, -0.5f, 0.0f }, { 0.0f, 0.0f, 1.0f }, { 0.0f, 0.0f } },
        { {  0.5f, -0.5f, 0.0f }, { 0.0f, 0.0f, 1.0f }, { 1.0f, 0.0f } },
        { {  0.0f,  0.5f, 0.0f }, { 0.0f, 0.0f, 1.0f }, { 0.5f, 1.0f } }
    };
    std::vector<uint32_t> indices = { 0, 1, 2 };

    m_Mesh = std::make_unique<Mesh>(vertices, indices);

    m_PhysicsWorld = std::make_unique<PhysicsWorld>();
}

Application::~Application() {
    Renderer::Shutdown();
}

void Application::Run() {
    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);

    while (m_Running && !m_Window->ShouldClose()) {
        m_Window->PollEvents();
        
        // Update Physics
        m_PhysicsWorld->Step(0.016f); // Dummy 60fps delta
        
        // Render
        Renderer::Clear();

        m_Shader->Bind();
        m_Mesh->Draw();
        
        m_Window->SwapBuffers();
    }
}

} // namespace ray
