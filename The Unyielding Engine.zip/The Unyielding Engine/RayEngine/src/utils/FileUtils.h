#pragma once

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>

namespace ray {
namespace utils {

class FileUtils {
public:
    static std::string ReadFile(const std::string& filepath) {
        std::ifstream file(filepath);
        if (!file.is_open()) {
            std::cerr << "Failed to open file: " << filepath << std::endl;
            return "";
        }

        std::stringstream buffer;
        buffer << file.rdbuf();
        return buffer.str();
    }
};

} // namespace utils
} // namespace ray
