#pragma once

#include <chrono>

namespace ray {
namespace utils {

class Timer {
public:
    Timer() {
        Reset();
    }

    void Reset() {
        m_Start = std::chrono::high_resolution_clock::now();
    }

    float GetElapsed() const {
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<float> duration = end - m_Start;
        return duration.count();
    }

private:
    std::chrono::time_point<std::chrono::high_resolution_clock> m_Start;
};

} // namespace utils
} // namespace ray
