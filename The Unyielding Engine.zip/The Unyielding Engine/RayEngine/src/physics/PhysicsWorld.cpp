#include "PhysicsWorld.h"
#include <iostream>

namespace ray {

PhysicsWorld::PhysicsWorld() {
    std::cout << "PhysicsWorld Initialized" << std::endl;
}

PhysicsWorld::~PhysicsWorld() {
    std::cout << "PhysicsWorld Destroyed" << std::endl;
}

void PhysicsWorld::Step(float dt) {
    // Physics step integration
}

} // namespace ray
