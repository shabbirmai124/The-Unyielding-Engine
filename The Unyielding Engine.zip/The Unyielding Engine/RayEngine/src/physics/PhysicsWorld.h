#pragma once

namespace ray {

class PhysicsWorld {
public:
    PhysicsWorld();
    ~PhysicsWorld();

    void Step(float dt);
};

} // namespace ray
