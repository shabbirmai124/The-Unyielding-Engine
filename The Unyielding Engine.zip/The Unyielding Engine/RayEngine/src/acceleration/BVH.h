#pragma once

namespace ray {

class BVH {
public:
    BVH();
    ~BVH();

    void Build();
};

} // namespace ray
