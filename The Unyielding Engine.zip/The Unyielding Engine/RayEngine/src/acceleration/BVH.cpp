#include "BVH.h"
#include <iostream>

namespace ray {

BVH::BVH() {
}

BVH::~BVH() {
}

void BVH::Build() {
    std::cout << "BVH Built" << std::endl;
}

} // namespace ray
