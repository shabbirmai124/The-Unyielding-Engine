#include "core/Application.h"
#include <iostream>

class Sandbox : public ray::Application {
public:
    Sandbox() : ray::Application("RayEngine Sandbox", 1280, 720) {
    }

    ~Sandbox() {
    }
};

ray::Application* ray::CreateApplication() {
    return new Sandbox();
}

int main(int argc, char** argv) {
    std::cout << "Starting RayEngine..." << std::endl;
    
    auto app = ray::CreateApplication();
    app->Run();
    delete app;
    
    return 0;
}
