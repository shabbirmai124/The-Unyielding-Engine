# RayEngine

A custom physics + ray tracing engine built with C++ and OpenGL.

## Features (Planned)
- Realschool CPU Ray Tracing
- GPU Compute Shader Acceleration
- Physics Simulation (Rigid body dynamics)
- BVH acceleration structures

## Build Instructions

1.  Clone repository.
2.  Configure with CMake: `cmake -S . -B build`
3.  Build: `cmake --build build`

## Dependencies (Automatically fetched)
- GLFW 3.3.8
- GLM 0.9.9.8
- GLAD (OpenGL 4.6 Core)
- ImGui (Docking branch)
