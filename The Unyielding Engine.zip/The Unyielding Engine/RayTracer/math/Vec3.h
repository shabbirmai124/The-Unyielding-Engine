#pragma once
#include <cmath>

class Vec3 {
public:
    double x, y, z;

    Vec3();
    Vec3(double x, double y, double z);

    Vec3 operator+(const Vec3& v) const;
    Vec3 operator-(const Vec3& v) const;
    Vec3 operator*(double t) const;
    Vec3 operator/(double t) const;

    double dot(const Vec3& v) const;
    Vec3 normalize() const;

    static Vec3 random();
    static Vec3 random(double min, double max);
};

