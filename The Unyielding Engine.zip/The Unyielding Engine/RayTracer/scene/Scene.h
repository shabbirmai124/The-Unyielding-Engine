#pragma once
#include <vector>
#include "../geometry/Sphere.h"
#include "../geometry/Hittable.h"
#include <memory> 

class Scene : public Hittable {
public:
    std::vector<std::shared_ptr<Hittable>> objects;

    void add(std::shared_ptr<Hittable> object);
    void clear();
    virtual bool hit(const Ray& ray, double t_min, double t_max, HitRecord& rec) const override;
    virtual bool bounding_box(double time0, double time1, AABB& output_box) const override;
};


