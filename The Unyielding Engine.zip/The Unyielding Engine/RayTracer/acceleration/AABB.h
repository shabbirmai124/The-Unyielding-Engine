#pragma once
#include "../math/Vec3.h"
#include "../core/Ray.h"

class AABB {
public:
    Vec3 min;
    Vec3 max;

    AABB() {}
    AABB(const Vec3& a, const Vec3& b) {
        min = Vec3(fmin(a.x, b.x), fmin(a.y, b.y), fmin(a.z, b.z));
        max = Vec3(fmax(a.x, b.x), fmax(a.y, b.y), fmax(a.z, b.z));
    }

    bool hit(const Ray& r, double t_min, double t_max) const {
        for (int a = 0; a < 3; a++) {
            auto invD = 1.0f / (a == 0 ? r.direction.x : (a == 1 ? r.direction.y : r.direction.z));
            auto t0 = ((a == 0 ? min.x : (a == 1 ? min.y : min.z)) - (a == 0 ? r.origin.x : (a == 1 ? r.origin.y : r.origin.z))) * invD;
            auto t1 = ((a == 0 ? max.x : (a == 1 ? max.y : max.z)) - (a == 0 ? r.origin.x : (a == 1 ? r.origin.y : r.origin.z))) * invD;
            if (invD < 0.0f) std::swap(t0, t1);
            t_min = t0 > t_min ? t0 : t_min;
            t_max = t1 < t_max ? t1 : t_max;
            if (t_max <= t_min) return false;
        }
        return true;
    }

    static AABB surrounding_box(const AABB& box0, const AABB& box1) {
        Vec3 small(fmin(box0.min.x, box1.min.x),
                   fmin(box0.min.y, box1.min.y),
                   fmin(box0.min.z, box1.min.z));
        Vec3 big(fmax(box0.max.x, box1.max.x),
                 fmax(box0.max.y, box1.max.y),
                 fmax(box0.max.z, box1.max.z));
        return AABB(small, big);
    }
};
