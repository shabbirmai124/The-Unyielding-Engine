#pragma once
#include "../scene/Scene.h"
#include "../core/Camera.h"

class Renderer {
public:
    void render(const Scene& scene, const Camera& camera);
};

