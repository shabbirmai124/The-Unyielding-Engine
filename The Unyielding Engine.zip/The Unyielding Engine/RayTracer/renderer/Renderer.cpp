#include "Renderer.h"
#include <fstream>
#include <iostream>
#include <algorithm>
#include <vector>
#include <thread>
#include <future>
#include <atomic>
#include "../utils/Random.h"
#include "../materials/Material.h"
#include "../core/Camera.h" // Includes Ray.h

// Forward declaration if needed, but Camera now handles ray gen
// We need to pass Camera to render()

Vec3 ray_color(const Ray& r, const Scene& scene, int depth) {
    HitRecord rec;

    if (depth <= 0)
        return Vec3(0,0,0);

    if (scene.hit(r, 0.001, 1e30, rec)) {
        Ray scattered(Vec3(0,0,0), Vec3(0,0,0));
        Vec3 attenuation;
        if (rec.mat_ptr->scatter(r, rec, attenuation, scattered))
            return attenuation * ray_color(scattered, scene, depth-1);
        return Vec3(0,0,0);
    }

    Vec3 unit_direction = r.direction.normalize();
    auto t = 0.5*(unit_direction.y + 1.0);
    return Vec3(1.0, 1.0, 1.0)*(1.0-t) + Vec3(0.5, 0.7, 1.0)*t;
}

void Renderer::render(const Scene& scene, const Camera& camera) {

    const int width = 800;
    const int height = 600;
    const int samples_per_pixel = 50; // Increased samples for higher quality!
    const int max_depth = 50;

    std::vector<Vec3> image_buffer(width * height);
    std::atomic<int> scanlines_remaining = height;

    auto render_scanline = [&](int j) {
        for (int i = 0; i < width; i++) {
            Vec3 color(0, 0, 0);
            for (int s = 0; s < samples_per_pixel; ++s) {
                auto u = (double(i) + random_double()) / (width-1);
                auto v = (double(j) + random_double()) / (height-1);
                Ray r = camera.get_ray(u, v);
                color = color + ray_color(r, scene, max_depth);
            }
            image_buffer[(height-1-j)*width + i] = color;
        }
        scanlines_remaining--;
        // Simple progress indicator (avoid spamming cerr from threads)
        if (scanlines_remaining % 10 == 0) 
            std::cerr << "\rScanlines remaining: " << scanlines_remaining << "   " << std::flush;
    };

    // Launch threads
    std::vector<std::future<void>> futures;
    int num_threads = std::thread::hardware_concurrency();
    if (num_threads == 0) num_threads = 4;
    
    std::cerr << "Rendering with " << num_threads << " threads..." << std::endl;

    // Direct Scanline Parallelism (Simple)
    // For a real engine, we'd use a thread pool, but std::async is fine for this scale.
    // However, creating 600 tasks might overhead. Let's chunk it.
    
    int lines_per_thread = height / num_threads;
    
    // We'll just use a simple approach: Spawn a thread for each core, and have them grab work
    // Or just simple std::async for each line if the overhead isn't too bad (it is on Windows).
    // Let's manually manage threads to process blocks of lines.

    std::vector<std::thread> threads;
    std::atomic<int> next_line = height - 1;

    for(int t=0; t<num_threads; ++t) {
        threads.emplace_back([&]() {
            int j;
            while((j = next_line--) >= 0) {
                render_scanline(j);
            }
        });
    }

    for(auto& thread : threads) {
        thread.join();
    }

    std::cerr << "\nDone. Writing to file...\n";

    std::ofstream out("output.ppm");
    out << "P3\n" << width << " " << height << "\n255\n";

    for (const auto& pixel_color : image_buffer) {
         auto scale = 1.0 / samples_per_pixel;
         auto r = std::sqrt(scale * pixel_color.x);
         auto g = std::sqrt(scale * pixel_color.y);
         auto b = std::sqrt(scale * pixel_color.z);

        out << static_cast<int>(256 * std::clamp(r, 0.0, 0.999)) << " "
            << static_cast<int>(256 * std::clamp(g, 0.0, 0.999)) << " "
            << static_cast<int>(256 * std::clamp(b, 0.0, 0.999)) << "\n";
    }
    out.close();
}


