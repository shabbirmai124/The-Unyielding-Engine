#pragma once
#include "Material.h"
#include "../geometry/HitRecord.h"

class Metal : public Material {
public:
    Vec3 albedo;
    double fuzz;

    Metal(const Vec3& a, double f) : albedo(a), fuzz(f < 1 ? f : 1) {}

    virtual bool scatter(const Ray& r_in, const HitRecord& rec, Vec3& attenuation, Ray& scattered) const override {
        Vec3 reflected = reflect(r_in.direction.normalize(), rec.normal);
        scattered = Ray(rec.p, reflected + random_in_unit_sphere() * fuzz);
        attenuation = albedo;
        return (scattered.direction.dot(rec.normal) > 0);
    }
};
