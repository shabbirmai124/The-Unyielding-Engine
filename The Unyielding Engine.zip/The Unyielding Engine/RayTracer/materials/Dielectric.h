#pragma once
#include "Material.h"
#include "../geometry/HitRecord.h"

class Dielectric : public Material {
public:
    double ir; // Index of Refraction

    Dielectric(double index_of_refraction) : ir(index_of_refraction) {}

    virtual bool scatter(const Ray& r_in, const HitRecord& rec, Vec3& attenuation, Ray& scattered) const override {
        attenuation = Vec3(1.0, 1.0, 1.0);
        double refraction_ratio = rec.front_face ? (1.0/ir) : ir;

        Vec3 unit_direction = r_in.direction.normalize();
        double cos_theta = std::fmin((-unit_direction).dot(rec.normal), 1.0);
        double sin_theta = std::sqrt(1.0 - cos_theta*cos_theta);

        bool cannot_refract = refraction_ratio * sin_theta > 1.0;
        Vec3 direction;

        if (cannot_refract || reflectance(cos_theta, refraction_ratio) > random_double())
            direction = reflect(unit_direction, rec.normal);
        else
            direction = refract(unit_direction, rec.normal, refraction_ratio);

        scattered = Ray(rec.p, direction);
        return true;
    }

private:
    static Vec3 refract(const Vec3& uv, const Vec3& n, double etai_over_etat) {
        double cos_theta = std::fmin((-uv).dot(n), 1.0);
        Vec3 r_out_perp = (uv + n * cos_theta) * etai_over_etat;
        Vec3 r_out_parallel = n * -std::sqrt(std::abs(1.0 - r_out_perp.dot(r_out_perp)));
        return r_out_perp + r_out_parallel;
    }

    static double reflectance(double cosine, double ref_idx) {
        // Schlick's approximation
        double r0 = (1-ref_idx) / (1+ref_idx);
        r0 = r0*r0;
        return r0 + (1-r0)*std::pow((1 - cosine), 5);
    }
};
