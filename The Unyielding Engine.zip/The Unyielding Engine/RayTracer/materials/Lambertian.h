#pragma once
#include "Material.h"
#include "../geometry/HitRecord.h"

class Lambertian : public Material {
public:
    Vec3 albedo;

    Lambertian(const Vec3& a) : albedo(a) {}

    virtual bool scatter(const Ray& r_in, const HitRecord& rec, Vec3& attenuation, Ray& scattered) const override {
        auto scatter_direction = rec.normal + random_unit_vector();

        // Catch degenerate scatter direction
        if (std::abs(scatter_direction.x) < 1e-8 && std::abs(scatter_direction.y) < 1e-8 && std::abs(scatter_direction.z) < 1e-8)
            scatter_direction = rec.normal;

        scattered = Ray(rec.p, scatter_direction);
        attenuation = albedo;
        return true;
    }
};
