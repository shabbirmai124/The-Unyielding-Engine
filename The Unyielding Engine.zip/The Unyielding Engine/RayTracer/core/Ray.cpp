#include "Ray.h"

Ray::Ray(const Vec3& o, const Vec3& d) : origin(o), direction(d) {}

Vec3 Ray::at(double t) const {
    return origin + direction * t;
}
