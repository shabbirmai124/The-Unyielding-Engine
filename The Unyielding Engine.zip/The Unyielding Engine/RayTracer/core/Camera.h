#pragma once

#include "../math/Vec3.h"
#include "../core/Ray.h"
#include <cmath>

class Camera {
public:
    Camera(
        Vec3 lookfrom,
        Vec3 lookat,
        Vec3 vup,
        double vfov, // vertical field-of-view in degrees
        double aspect_ratio,
        double aperture,
        double focus_dist
    ) {
        auto theta = degrees_to_radians(vfov);
        auto h = tan(theta/2);
        auto viewport_height = 2.0 * h;
        auto viewport_width = aspect_ratio * viewport_height;

        w = (lookfrom - lookat).normalize();
        u = vup.cross(w).normalize();
        v = w.cross(u);

        origin = lookfrom;
        horizontal = u * viewport_width * focus_dist;
        vertical = v * viewport_height * focus_dist;
        lower_left_corner = origin - horizontal/2 - vertical/2 - w*focus_dist;

        lens_radius = aperture / 2;
    }

    Ray get_ray(double s, double t) const {
        Vec3 rd = random_in_unit_disk() * lens_radius;
        Vec3 offset = u * rd.x + v * rd.y;

        return Ray(
            origin + offset,
            lower_left_corner + horizontal*s + vertical*t - origin - offset
        );
    }

private:
    Vec3 origin;
    Vec3 lower_left_corner;
    Vec3 horizontal;
    Vec3 vertical;
    Vec3 u, v, w;
    double lens_radius;

    static double degrees_to_radians(double degrees) {
        return degrees * 3.1415926535897932385 / 180.0;
    }

    static Vec3 random_in_unit_disk() {
        while (true) {
            auto p = Vec3(random_double(-1,1), random_double(-1,1), 0);
            if (p.dot(p) >= 1) continue;
            return p;
        }
    }
};
