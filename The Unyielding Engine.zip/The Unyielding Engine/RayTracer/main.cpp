#include "renderer/Renderer.h"
#include "scene/Scene.h"
#include "geometry/Sphere.h"
#include "materials/Lambertian.h"
#include "materials/Metal.h"
#include "materials/Dielectric.h"
#include "core/Camera.h"
#include <memory>
#include "acceleration/BVH.h"

int main() {
    Scene scene;

    // Ground
    auto material_ground = std::make_shared<Lambertian>(Vec3(0.8, 0.8, 0.0));
    scene.add(std::make_shared<Sphere>(Vec3(0.0, -100.5, -1.0), 100.0, material_ground));

    // Center - Diffuse (Matte)
    auto material_center = std::make_shared<Lambertian>(Vec3(0.1, 0.2, 0.5));
    scene.add(std::make_shared<Sphere>(Vec3(0.0, 0.0, -1.0), 0.5, material_center));

    // Left - Glass (Dielectric)
    auto material_left = std::make_shared<Dielectric>(1.5);
    scene.add(std::make_shared<Sphere>(Vec3(-1.0, 0.0, -1.0), 0.5, material_left));
    // Bubble effect (hollow glass)
    scene.add(std::make_shared<Sphere>(Vec3(-1.0, 0.0, -1.0), -0.45, material_left));

    // Right - Metal
    auto material_right = std::make_shared<Metal>(Vec3(0.8, 0.6, 0.2), 0.0);
    scene.add(std::make_shared<Sphere>(Vec3(1.0, 0.0, -1.0), 0.5, material_right));

    // Create BVH (This creates a new scene containing just the root node of the tree)
    Scene bvh_scene;
    bvh_scene.add(std::make_shared<BVHNode>(scene.objects, 0.0, 1.0));


    // Camera
    Vec3 lookfrom(3,3,2);
    Vec3 lookat(0,0,-1);
    Vec3 vup(0,1,0);
    auto dist_to_focus = (lookfrom-lookat).dot(lookfrom-lookat); // Rough focus dist
    dist_to_focus = sqrt(dist_to_focus);
    double aperture = 0.2; // Increase for more blur

    Camera camera(lookfrom, lookat, vup, 20, 800.0/600.0, aperture, dist_to_focus);

    Renderer renderer;
    renderer.render(bvh_scene, camera);

    return 0;
}


