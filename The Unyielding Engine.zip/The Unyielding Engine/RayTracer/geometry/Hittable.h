#pragma once
#include "../core/Ray.h"
#include "../geometry/HitRecord.h"
#include "../acceleration/AABB.h"

class Hittable {
public:
    virtual bool hit(const Ray& r, double t_min, double t_max, HitRecord& rec) const = 0;
    virtual bool bounding_box(double time0, double time1, AABB& output_box) const = 0;
};
