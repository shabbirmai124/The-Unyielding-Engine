#pragma once
#include "../geometry/HitRecord.h"
#include "../geometry/Hittable.h"

class Sphere : public Hittable {
public:
    Vec3 center;
    double radius;
    std::shared_ptr<Material> mat_ptr;

    Sphere(Vec3 c, double r, std::shared_ptr<Material> m);
    virtual bool hit(const Ray& ray, double t_min, double t_max, HitRecord& rec) const override;
    virtual bool bounding_box(double time0, double time1, AABB& output_box) const override;
};


